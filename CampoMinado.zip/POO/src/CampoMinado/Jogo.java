package CampoMinado;

public class Jogo {

}
